# KymCar

Full-stack MVP площадки автомобилей с пробегом: Node.js + Express + PostgreSQL.

## Локальный запуск

1. Установить Node.js 20+.
2. Создать PostgreSQL и переменную `DATABASE_URL`.
3. Выполнить `npm install`.
4. Запустить `npm start`.
5. Открыть http://localhost:3000

## Render

Проект содержит `render.yaml`. В Render выберите New → Blueprint и подключите этот GitHub-репозиторий. Конфигурация создаёт Web Service и PostgreSQL и связывает их через `DATABASE_URL`.

## Демо

Администратор: admin@kymcar.local / KymCar123!

При первом запуске база и демонстрационные автомобили создаются автоматически.
