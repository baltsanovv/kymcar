const express = require('express');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev-only-change-me';
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false });

app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

async function db(sql, params = []) { const r = await pool.query(sql, params); return r.rows; }
async function initDb() {
  await db(`CREATE TABLE IF NOT EXISTS users (id SERIAL PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user', created_at TIMESTAMPTZ DEFAULT NOW())`);
  await db(`CREATE TABLE IF NOT EXISTS cars (id SERIAL PRIMARY KEY, user_id INTEGER REFERENCES users(id) ON DELETE SET NULL, make TEXT NOT NULL, model TEXT NOT NULL, year INTEGER NOT NULL, price INTEGER NOT NULL, mileage INTEGER DEFAULT 0, fuel TEXT DEFAULT 'Бензин', transmission TEXT DEFAULT 'Автомат', city TEXT DEFAULT '', image_url TEXT DEFAULT '', description TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'active', created_at TIMESTAMPTZ DEFAULT NOW())`);
  await db(`CREATE TABLE IF NOT EXISTS favorites (user_id INTEGER REFERENCES users(id) ON DELETE CASCADE, car_id INTEGER REFERENCES cars(id) ON DELETE CASCADE, PRIMARY KEY(user_id, car_id))`);
  const admins = await db(`SELECT id FROM users WHERE email=$1`, ['admin@kymcar.local']);
  if (!admins.length) {
    const hash = await bcrypt.hash('KymCar123!', 12);
    await db(`INSERT INTO users(name,email,password_hash,role) VALUES($1,$2,$3,'admin')`, ['KymCar Admin','admin@kymcar.local',hash]);
  }
  const count = await db(`SELECT COUNT(*)::int AS count FROM cars`);
  if (count[0].count === 0) {
    const demo = [
      ['Mercedes-Benz','E-Class',2010,109000,238000,'Дизель','Автомат','Москва','https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&w=1200&q=80','Комфортный W212 в хорошем состоянии.'],
      ['BMW','5 Series',2014,139000,182000,'Бензин','Автомат','Санкт-Петербург','https://images.unsplash.com/photo-1555215695-3004980ad54e?auto=format&fit=crop&w=1200&q=80','Ухоженная пятёрка, богатая комплектация.'],
      ['Audi','Q5',2017,189000,126000,'Бензин','Автомат','Казань','https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?auto=format&fit=crop&w=1200&q=80','Городской кроссовер для ежедневных поездок.'],
      ['Toyota','Camry',2019,205000,92000,'Бензин','Автомат','Москва','https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?auto=format&fit=crop&w=1200&q=80','Надёжная Camry с прозрачной историей.']
    ];
    for (const c of demo) await db(`INSERT INTO cars(make,model,year,price,mileage,fuel,transmission,city,image_url,description) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`, c);
  }
}
function tokenFor(user) { return jwt.sign({ id:user.id, role:user.role, name:user.name, email:user.email }, JWT_SECRET, { expiresIn:'7d' }); }
function auth(req,res,next) { const t=req.cookies.kymcar_token; if(!t) return res.status(401).json({error:'Требуется вход'}); try { req.user=jwt.verify(t,JWT_SECRET); next(); } catch { res.clearCookie('kymcar_token'); return res.status(401).json({error:'Сессия истекла'}); } }
function admin(req,res,next) { if(req.user.role!=='admin') return res.status(403).json({error:'Доступ только для администратора'}); next(); }

app.get('/api/health', async (req,res)=>{ try { await db('SELECT 1'); res.json({ok:true}); } catch(e) { res.status(503).json({ok:false,error:e.message}); }});
app.get('/api/me',(req,res)=>{ const t=req.cookies.kymcar_token; if(!t) return res.json({user:null}); try { res.json({user:jwt.verify(t,JWT_SECRET)}); } catch { res.json({user:null}); }});
app.post('/api/register', async (req,res)=>{ try { const {name,email,password}=req.body; if(!name||!email||!password||password.length<6) return res.status(400).json({error:'Имя, email и пароль от 6 символов обязательны'}); const exists=await db('SELECT id FROM users WHERE email=$1',[email.toLowerCase().trim()]); if(exists.length) return res.status(409).json({error:'Email уже зарегистрирован'}); const hash=await bcrypt.hash(password,12); const rows=await db('INSERT INTO users(name,email,password_hash) VALUES($1,$2,$3) RETURNING id,name,email,role',[name,email.toLowerCase().trim(),hash]); res.cookie('kymcar_token',tokenFor(rows[0]),{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:604800000}); res.json({user:rows[0]}); } catch(e){res.status(500).json({error:'Ошибка регистрации'});} });
app.post('/api/login', async (req,res)=>{ try { const {email,password}=req.body; const rows=await db('SELECT * FROM users WHERE email=$1',[String(email||'').toLowerCase().trim()]); if(!rows.length || !(await bcrypt.compare(password||'',rows[0].password_hash))) return res.status(401).json({error:'Неверный email или пароль'}); const u={id:rows[0].id,name:rows[0].name,email:rows[0].email,role:rows[0].role}; res.cookie('kymcar_token',tokenFor(u),{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:604800000}); res.json({user:u}); } catch(e){res.status(500).json({error:'Ошибка входа'});} });
app.post('/api/logout',(req,res)=>{res.clearCookie('kymcar_token');res.json({ok:true});});
app.get('/api/cars', async (req,res)=>{ try { const {make,model,yearFrom,yearTo,priceTo,sort='new'}=req.query; const p=[]; const w=["status='active'"]; if(make){p.push(make);w.push(`make=$${p.length}`)} if(model){p.push(model);w.push(`model=$${p.length}`)} if(yearFrom){p.push(Number(yearFrom));w.push(`year>=$${p.length}`)} if(yearTo){p.push(Number(yearTo));w.push(`year<=$${p.length}`)} if(priceTo){p.push(Number(priceTo));w.push(`price<=$${p.length}`)} const order={price_asc:'price ASC',price_desc:'price DESC',year_desc:'year DESC',mileage_asc:'mileage ASC',new:'created_at DESC'}[sort]||'created_at DESC'; const rows=await db(`SELECT c.*,u.name AS seller_name FROM cars c LEFT JOIN users u ON u.id=c.user_id WHERE ${w.join(' AND ')} ORDER BY ${order}`,p); res.json(rows); } catch(e){res.status(500).json({error:'Ошибка каталога'});} });
app.get('/api/cars/:id', async(req,res)=>{const rows=await db('SELECT c.*,u.name seller_name,u.email seller_email FROM cars c LEFT JOIN users u ON u.id=c.user_id WHERE c.id=$1',[req.params.id]); if(!rows.length)return res.status(404).json({error:'Автомобиль не найден'}); res.json(rows[0]);});
app.post('/api/cars',auth,async(req,res)=>{ try { const {make,model,year,price,mileage,fuel,transmission,city,image_url,description}=req.body; if(!make||!model||!year||!price)return res.status(400).json({error:'Марка, модель, год и цена обязательны'}); const rows=await db(`INSERT INTO cars(user_id,make,model,year,price,mileage,fuel,transmission,city,image_url,description) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,[req.user.id,make,model,year,price,mileage||0,fuel||'Бензин',transmission||'Автомат',city||'',image_url||'',description||'']); res.status(201).json(rows[0]); }catch(e){res.status(500).json({error:'Не удалось создать объявление'});} });
app.put('/api/cars/:id',auth,async(req,res)=>{ const own=await db('SELECT id FROM cars WHERE id=$1 AND user_id=$2',[req.params.id,req.user.id]); if(!own.length && req.user.role!=='admin')return res.status(403).json({error:'Нет доступа'}); const {make,model,year,price,mileage,fuel,transmission,city,image_url,description,status}=req.body; const rows=await db(`UPDATE cars SET make=$1,model=$2,year=$3,price=$4,mileage=$5,fuel=$6,transmission=$7,city=$8,image_url=$9,description=$10,status=COALESCE($11,status) WHERE id=$12 RETURNING *`,[make,model,year,price,mileage,fuel,transmission,city,image_url,description,status,req.params.id]); res.json(rows[0]); });
app.delete('/api/cars/:id',auth,async(req,res)=>{ const own=await db('SELECT id FROM cars WHERE id=$1 AND user_id=$2',[req.params.id,req.user.id]); if(!own.length&&req.user.role!=='admin')return res.status(403).json({error:'Нет доступа'}); await db('DELETE FROM cars WHERE id=$1',[req.params.id]); res.json({ok:true}); });
app.get('/api/favorites',auth,async(req,res)=>res.json(await db('SELECT c.* FROM favorites f JOIN cars c ON c.id=f.car_id WHERE f.user_id=$1 ORDER BY f.car_id DESC',[req.user.id])));
app.post('/api/favorites/:id',auth,async(req,res)=>{await db('INSERT INTO favorites(user_id,car_id) VALUES($1,$2) ON CONFLICT DO NOTHING',[req.user.id,req.params.id]);res.json({ok:true});});
app.delete('/api/favorites/:id',auth,async(req,res)=>{await db('DELETE FROM favorites WHERE user_id=$1 AND car_id=$2',[req.user.id,req.params.id]);res.json({ok:true});});
app.get('/api/my/cars',auth,async(req,res)=>res.json(await db('SELECT * FROM cars WHERE user_id=$1 ORDER BY created_at DESC',[req.user.id])));
app.get('/api/admin/stats',auth,admin,async(req,res)=>{const a=await db('SELECT COUNT(*)::int count FROM users');const b=await db('SELECT COUNT(*)::int count FROM cars');const c=await db("SELECT COUNT(*)::int count FROM cars WHERE status='active'");res.json({users:a[0].count,cars:b[0].count,active:c[0].count});});

app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
initDb().then(()=>app.listen(PORT,()=>console.log(`KymCar running on ${PORT}`))).catch(e=>{console.error(e);process.exit(1)});
